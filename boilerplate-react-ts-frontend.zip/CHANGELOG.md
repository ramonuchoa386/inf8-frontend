# 1.0.0 (06/04/2022)

## Boilerplate

- Documentação
- Storybook
- Routes
- Lógica de publico e privado

# 0.1.0 (01/04/2022)

## Getting Started

- Estrutura
- Eslint
- Prietter
- Husky
