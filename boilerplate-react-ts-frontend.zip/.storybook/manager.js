import { addons } from '@storybook/addons';
import APIM from './theme';

addons.setConfig({
  theme: APIM,
});
