import React from 'react';
import { ContentPagePrivate } from '../../../components/templates';

const Cwp = () => {
  return (
    <ContentPagePrivate pageTitle='Cwp'>
      <div>Cwp</div>
    </ContentPagePrivate>
  );
};

export default Cwp;
