import styled from 'styled-components';

export const IconWrapper = styled.img`
  display: block;
`;
