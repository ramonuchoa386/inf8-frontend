import styled from 'styled-components';

export const Imagem = styled.img`
  max-width: 100%;
`;
