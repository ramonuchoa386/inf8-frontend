import styled from 'styled-components';

export const Main = styled.div``;
