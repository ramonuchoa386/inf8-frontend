import ContentPagePrivate from './contentPagesPrivate';

export { ContentPagePrivate };
